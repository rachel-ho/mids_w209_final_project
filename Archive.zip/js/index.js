var padding = 200;
var parseTime = d3.timeParse("%Y-%m-%e");
var rowConverter1 = function(d) {
    return {
        name: d.Name,
        //alignment: (["Bad", "Good"].indexOf(d.Alignment) > -1) ? d.Alignment : "Other",
        //alignment: (d.Alignment == "Bad" || d.Alignment == "Good") ? d.Alignment : "Other",
        alignment: d.Alignment,
        gender: d.Gender,
        publisher: d.Publisher,
        identity: d.Identity,
        race: d.Race,
        status: d.Status,
        eyeColor: d.EyeColor,
        hairColor: d.HairColor,
        skinColor: d.SkinColor,
        height: parseFloat(d.Height),
        weight: parseFloat(d.Weight),
        appearances: parseFloat(d.Appearances),
        yearFirstAppearance: parseFloat(d.Year),
        dateFirstAppearance: parseTime(d.FirstAppearance),
        additional: d.AdditionalData
    };
}

d3.csv("https://raw.githubusercontent.com/rachel-ho/mids_w209_final_project/master/superheroes_info_proc.csv", rowConverter1).then(function(dataset) {
    var data = dataset.filter(function(d) { return !isNaN(d.yearFirstAppearance); })
    //console.log(data);

    var ndx = crossfilter(data);
    var yearBinDimension = ndx.dimension(function(d) { return Math.floor(d.yearFirstAppearance / 5) * 5; })
    var yearBinCount = yearBinDimension.group().all();
    //console.log(yearBinCount);

    function reduceAddAlignment(p, v) {
        ++p.total;
        p.bad += (v.alignment == "Bad") ? 1 : 0;
        p.good += (v.alignment == "Good") ? 1 : 0;
        p.other += (v.alignment == "Other") ? 1 : 0;
        return p;
    }
    function reduceRemoveAlignment(p, v) {
        --p.total;
        p.bad -= (v.alignment == "Bad") ? 1 : 0;
        p.good -= (v.alignment == "Good") ? 1 : 0;
        p.other -= (v.alignment == "Other") ? 1 : 0;
        return p;
    }
    function reduceInitialAlignment() {
        return {total: 0, bad: 0, good: 0, other: 0};
    }
    var alignmentByYear = yearBinDimension.group().reduce(reduceAddAlignment, reduceRemoveAlignment, reduceInitialAlignment).all();
    //console.log(alignmentByYear);

    var alignmentByYearFlat = [];
    for (var i = 0; i < alignmentByYear.length; i++) {
        alignmentByYearFlat.push(alignmentByYear[i].value);
    }
    //console.log(alignmentByYearFlat);

    function reduceAddGender(p, v) {
        ++p.total;
        p.male += (v.gender == "Male") ? 1 : 0;
        p.female += (v.gender == "Female") ? 1 : 0;
        p.other += (v.gender == "Other") ? 1 : 0;
        return p;
    }
    function reduceRemoveGender(p, v) {
        --p.total;
        p.male -= (v.gender == "Male") ? 1 : 0;
        p.female -= (v.gender == "Female") ? 1 : 0;
        p.other -= (v.gender == "Other") == -1 ? 1 : 0;
        return p;
    }
    function reduceInitialGender() {
        return {total: 0, male: 0, female: 0, other: 0};
    }
    var genderByYear = yearBinDimension.group().reduce(reduceAddGender, reduceRemoveGender, reduceInitialGender).all();
    //console.log(genderByYear);

    var genderByYearFlat = [];
    for (var i = 0; i < genderByYear.length; i++) {
        genderByYearFlat.push(genderByYear[i].value);
    }
    //console.log(genderByYearFlat);

    function reduceAddPublisher(p, v) {
        ++p.total;
        p.marvel += (v.publisher == "Marvel") ? 1 : 0;
        p.dc += (v.publisher == "DC") ? 1 : 0;
        p.other += (v.publisher == "Other") ? 1 : 0;
        return p;
    }
    function reduceRemovePublisher(p, v) {
        --p.total;
        p.marvel -= (v.publisher == "Marvel") ? 1 : 0;
        p.dc -= (v.publisher == "DC") ? 1 : 0;
        p.other -= (v.publisher == "Other") ? 1 : 0;
        return p;
    }
    function reduceInitialPublisher() {
        return {total: 0, marvel: 0, dc: 0, other: 0};
    }
    var publisherByYear = yearBinDimension.group().reduce(reduceAddPublisher, reduceRemovePublisher, reduceInitialPublisher).all();
    //console.log(publisherByYear);

    var publisherByYearFlat = [];
    for (var i = 0; i < publisherByYear.length; i++) {
        publisherByYearFlat.push(publisherByYear[i].value);
    }
    //console.log(publisherByYearFlat);

    var trendSVG = d3.select("#trend").select("svg");
    var trendSVGWidth = trendSVG.attr("width");
    var trendSVGHeight = trendSVG.attr("height");

    //console.log(Object.getOwnPropertyNames(genderByYear[0].value).slice(1));
    var stack = d3.stack()
                    .keys(Object.getOwnPropertyNames(alignmentByYear[0].value).slice(1))
                    .order(d3.stackOrderDescending);

    var series = stack(alignmentByYearFlat);
    //console.log(series);

    var xScale = d3.scaleBand()
                    .domain(d3.range(yearBinCount.length))
                    .range([padding, trendSVGWidth])
                    .paddingInner(0.05);

    var yScale = d3.scaleLinear()
                    .domain([0, d3.max(alignmentByYear, function(d) { return d.value.total; })])
                    .range([trendSVGHeight - padding, 0]);

    var xAxis = d3.axisBottom()
                    .scale(xScale)
                    .tickFormat(function(d, i) { return yearBinCount[i].key; });

    var yAxis = d3.axisLeft()
                 .scale(yScale)
                 .ticks(5);

    var colors = d3.scaleOrdinal(d3.schemeSet1);

    var trendGroup = trendSVG.selectAll("g")
                                .data(series)
                                .enter()
                                .append("g")
                                .style("fill", function(d, i) { return colors(i); });

    var trendRect = trendGroup.selectAll("rect")
                                .data(function(d) { return d; })
                                .enter()
                                .append("rect")
                                .attr("x", function(d, i) { return xScale(i); })
                                .attr("y", function(d) { return yScale(d[1]); })
                                .attr("width", xScale.bandwidth())
                                .attr("height", function(d) { return yScale(d[0]) - yScale(d[1]); });

    trendSVG.append("g")
            .attr("class", "xaxis")
            .attr("transform", "translate(0," + (trendSVGHeight - padding) + ")")
            .call(xAxis);

    trendSVG.append("g")
            .attr("class", "yaxis")
            .attr("transform", "translate(" + padding + ",0)")
            .call(yAxis);

    trendSVG.append("g")
            .append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", padding - 60)
            .attr("x", (-trendSVGHeight + padding) / 2)
            .text("Number of Superheroes Created")
            .style ("text-anchor", "middle");

    var legendScale = d3.scaleOrdinal()
                        .domain(Object.getOwnPropertyNames(alignmentByYear[0].value).slice(1))
                        .range(["#e41a1c", "#377eb8", "#4daf4a"]);

    var legendOrdinal = d3.legendColor()
                            .orient("vertical")
                            .scale(legendScale);

    trendSVG.append("g")
            .attr("id", "legend")
            .attr("transform", "translate(" + (padding + 30) + ", 10)")
            .call(legendOrdinal);

    d3.selectAll("#radio")
        .on("click", function() {
            var view = d3.select(this).node().value;

            switch (view) {
                case "alignment":
                    stack.keys(Object.getOwnPropertyNames(alignmentByYear[0].value).slice(1));
                    series = stack(alignmentByYearFlat);

                    trendSVG.selectAll("g")
                            .data(series)
                            .selectAll("rect")
                            .data(function(d) { return d; })
                            .transition()
                            .duration(1000)
                            .attr("y", function(d) { return yScale(d[1]); })
                            .attr("height", function(d) { return yScale(d[0]) - yScale(d[1]); });

                    legendScale.domain(Object.getOwnPropertyNames(alignmentByYear[0].value).slice(1))
                                .range(["#e41a1c", "#377eb8", "#4daf4a"]);
                    trendSVG.select("#legend")
                            .call(legendOrdinal);
                    break;

                case "gender":
                    stack.keys(Object.getOwnPropertyNames(genderByYear[0].value).slice(1));
                    series = stack(genderByYearFlat);

                    trendSVG.selectAll("g")
                            .data(series)
                            .selectAll("rect")
                            .data(function(d) { return d; })
                            .transition()
                            .duration(1000)
                            .attr("y", function(d) { return yScale(d[1]); })
                            .attr("height", function(d) { return yScale(d[0]) - yScale(d[1]); });

                    legendScale.domain(Object.getOwnPropertyNames(genderByYear[0].value).slice(1))
                                .range(["#e41a1c", "#377eb8", "#4daf4a"]);
                    trendSVG.select("#legend")
                            .call(legendOrdinal);
                    break;

                case "publisher":
                    stack.keys(Object.getOwnPropertyNames(publisherByYear[0].value).slice(1));
                    series = stack(publisherByYearFlat);

                    trendSVG.selectAll("g")
                            .data(series)
                            .selectAll("rect")
                            .data(function(d) { return d; })
                            .transition()
                            .duration(1000)
                            .attr("y", function(d) { return yScale(d[1]); })
                            .attr("height", function(d) { return yScale(d[0]) - yScale(d[1]); });

                    legendScale.domain(Object.getOwnPropertyNames(publisherByYear[0].value).slice(1))
                                .range(["#e41a1c", "#377eb8", "#4daf4a"]);
                    trendSVG.select("#legend")
                            .call(legendOrdinal);
                    break;
            };
        });

});

var rowConverter2 = function(d) {
    return {
        name: d.Name,
        intelligence: parseFloat(d.Intelligence),
        strength: parseFloat(d.Strength),
        speed: parseFloat(d.Speed),
        durability: parseFloat(d.Durability),
        power: parseFloat(d.Power),
        combat: parseFloat(d.Combat),
        total: parseFloat(d.Total),
        alignment: d.Alignment,
        gender: d.Gender,
        publisher: d.Publisher,
        appearances: parseFloat(d.Appearances),
    };
}

d3.csv("https://raw.githubusercontent.com/rachel-ho/mids_w209_final_project/master/superheroes_stats_proc.csv", rowConverter2).then(function(dataset) {
    function plot(publisher, inputData) {
        //var data = inputData.filter(function(d) { return (d.publisher == publisher) && (d.appearances >= 100); })
        var data = inputData.filter(function(d) { return d.publisher == publisher; })
        //console.log(data);

        var n = 10;
        var ndx = crossfilter(data);
        var powerDimension = ndx.dimension(function(d) { return d.total; })
        var topPower = powerDimension.top(n);
        //console.log(topPower);

        var powerSVG = d3.select("#" + publisher + "-power").select("svg");
        var powerSVGWidth = powerSVG.attr("width");
        var powerSVGHeight = powerSVG.attr("height");
        powerSVG.selectAll("*").remove();

        var xScale = d3.scaleLinear()
                        .domain([0, d3.max(topPower, function(d) { return d.total; })])
                        .range([padding, powerSVGWidth - 10]);

        var yScale = d3.scaleBand()
                        .domain(d3.range(topPower.length))
                        .rangeRound([0, powerSVGHeight - padding])
                        .paddingInner(0.05);

        var xAxis = d3.axisBottom()
                        .scale(xScale)
                        .ticks(5);

        var yAxis = d3.axisLeft()
                     .scale(yScale)
                     .tickFormat(function(d, i) { return topPower[i].name; });

        powerSVG.selectAll("rect")
                .data(topPower)
                .enter()
                .append("rect")
                .attr("x", xScale(0))
                .attr("y", function(d, i) {
                    return yScale(i);
                })
                .attr("width", function(d) {
                    return xScale(d.total) - padding;
                })
                .attr("height", yScale.bandwidth())
                .attr("fill", function(d) {
                    if (d.gender == "Female") {
                        return "#e41a1c";
                    } else if (d.gender == "Male") {
                        return "#377eb8";
                    } else {
                        return "#4daf4a";
                    }
                })
                .on("mouseover", function(d) {
                    var xPosition = parseFloat(d3.select(this).attr("width")) + padding - 25;
                    var yPosition = parseFloat(d3.select(this).attr("y")) + yScale.bandwidth() / 2 + 4;
                    powerSVG.append("text")
                            .attr("id", "tooltip")
                            .attr("x", xPosition)
                            .attr("y", yPosition)
                            .text(Math.round(d.total));
                })
                .on("mouseout", function(d) {
                    d3.select("#tooltip").remove();
                });
        powerSVG.append("g")
                .attr("class", "xaxis")
                .attr("transform", "translate(0," + (powerSVGHeight - padding) + ")")
                .call(xAxis);

        powerSVG.append("g")
                .attr("class", "yaxis")
                .attr("transform", "translate(" + padding + ",0)")
                .call(yAxis);
    };

    plot("DC", dataset);
    plot("Marvel", dataset);

    d3.selectAll("#slider")
        .on("change", function() {
            var threshold = +d3.select(this).node().value;
            //console.log(threshold);
            var filterData = dataset.filter(function(d) { return d.appearances >= threshold; })
            plot("DC", filterData);
            plot("Marvel", filterData);
        });
});

d3.csv("https://raw.githubusercontent.com/rachel-ho/mids_w209_final_project/master/superheroes_stats_proc.csv", rowConverter2).then(function(dataset) {
    var n = 20;
    var powerCat = ["combat", "durability", "intelligence", "power", "speed", "strength"];
    var dcData = dataset.filter(function(d) { return d.publisher == "DC"; })
                        .sort(function(a, b) { return b.appearances - a.appearances; })
                        .slice(0, n);
    var marvelData = dataset.filter(function(d) { return d.publisher == "Marvel"; })
                        .sort(function(a, b) { return b.appearances - a.appearances; })
                        .slice(0, n);
    console.log(dcData);
    //console.log(marvelData);

    function createDropdown(publisher, inputData) {
        d3.select("#" + publisher + "-dropdown")
            .selectAll("option")
            .data(inputData)
            .enter()
            .append("option")
            .text(function(d) { return d.name; });
    };

    createDropdown("DC", dcData);
    createDropdown("Marvel", marvelData);

    //Default plot for first
    var dcDefaultCharacter = dcData[0].name;
    var marvelDefaultCharacter = marvelData[0].name;
    //console.log(dcDefaultCharacter);
    //console.log(marvelDefaultCharacter);
    var dcDefaultIndex = dcData.findIndex(function(d) { return d.name == dcDefaultCharacter; });
    var marvelDefaultIndex = marvelData.findIndex(function(d) { return d.name == marvelDefaultCharacter; });
    //console.log(dcDefaultIndex);
    //console.log(marvelDefaultIndex);

    function plot(publisher, index) {
        if (publisher == "DC") {
            var dataPlot = Object.entries(dcData[index])
                                    .map(([key, value]) => ({key, value}))
                                    .filter(function(d) { return powerCat.indexOf(d.key) > -1; })
                                    .sort(function(a, b) { return (a.key > b.key) ? 1 : ((b.key > a.key) ? -1 : 0)});
            console.log(dataPlot);
        } else {
            var dataPlot = Object.entries(marvelData[index])
                                    .map(([key, value]) => ({key, value}))
                                    .filter(function(d) { return powerCat.indexOf(d.key) > -1; })
                                    .sort(function(a, b) { return (a.key > b.key) ? 1 : ((b.key > a.key) ? -1 : 0)});
            console.log(dataPlot);
        }

        var powerCatSVG = d3.select("#" + publisher + "-power-category").select("svg");
        var powerCatSVGWidth = powerCatSVG.attr("width");
        var powerCatSVGHeight = powerCatSVG.attr("height");
        powerCatSVG.selectAll("*").remove();

        var xScale = d3.scaleLinear()
                        .domain([0, 120])
                        .range([padding, powerCatSVGWidth - 10]);

        var yScale = d3.scaleBand()
                        .domain(powerCat)
                        .rangeRound([0, powerCatSVGHeight - padding])
                        .padding(1);

        var xAxis = d3.axisBottom()
                        .scale(xScale)
                        .ticks(5);

        var yAxis = d3.axisLeft()
                     .scale(yScale)
                     .tickFormat(function(d, i) { return dataPlot[i].key; });

        powerCatSVG.selectAll("line")
                    .data(dataPlot)
                    .enter()
                    .append("line")
                    .attr("id", "barplot-line")
                    .attr("x1", xScale(0))
                    .attr("x2", xScale(0))
                    .attr("y1", function(d) { return yScale(d.key); })
                    .attr("y2", function(d) { return yScale(d.key); })
                    .transition("line-transition")
                    .duration(1000)
                    .attr("x2", function(d) { return xScale(d.value); });

        powerCatSVG.selectAll("mycircle")
                    .data(dataPlot)
                    .enter()
                    .append("circle")
                    .attr("id", "barplot-circle")
                    .attr("cx", xScale(0))
                    .attr("cy", function(d) { return yScale(d.key); })
                    .transition("circle-transition")
                    .duration(1000)
                    .attr("cx", function(d) { return xScale(d.value); })
                    .attr("r", "4");

        powerCatSVG.append("g")
                    .attr("class", "xaxis")
                    .attr("transform", "translate(0," + (powerCatSVGHeight - padding) + ")")
                    .call(xAxis);

        powerCatSVG.append("g")
                    .attr("class", "yaxis")
                    .attr("transform", "translate(" + padding + ",0)")
                    .call(yAxis);
    };

    plot("DC", dcDefaultIndex);
    plot("Marvel", marvelDefaultIndex);

    d3.select("#DC-dropdown")
        .on("change", function(d) {
            var selectedCharacter = d3.select(this).property("value");
            console.log(selectedCharacter);
            var selectedIndex = dcData.findIndex(function(d) { return d.name == selectedCharacter; });
            plot("DC", selectedIndex);
        });

    d3.select("#Marvel-dropdown")
        .on("change", function(d) {
            var selectedCharacter = d3.select(this).property("value");
            console.log(selectedCharacter);
            var selectedIndex = marvelData.findIndex(function(d) { return d.name == selectedCharacter; });
            plot("Marvel", selectedIndex);
        });

});
/*
d3.csv("https://raw.githubusercontent.com/rachel-ho/mids_w209_final_project/master/superheroes_stats_proc.csv", rowConverter2).then(function(dataset) {
    function plot(publisher, inputData) {
        var n = 20;
        var powerCat = ["combat", "durability", "intelligence", "power", "speed", "strength"];
        var data = inputData.filter(function(d) { return d.publisher == publisher; })
                            .sort(function(a, b) { return b.appearances - a.appearances; })
                            .slice(0, n);
        //console.log(data);
        var dataPlot = Object.entries(data[0])
                                .map(([key, value]) => ({key, value}))
                                .filter(function(d) { return powerCat.indexOf(d.key) > -1; });
        //console.log(dataPlot);

        d3.select("#" + publisher + "-dropdown")
            .selectAll("option")
            .data(data)
            .enter()
            .append("option")
            .text(function(d) { return d.name; });

        var powerCatSVG = d3.select("#" + publisher + "-power-category").select("svg");
        var powerCatSVGWidth = powerCatSVG.attr("width");
        var powerCatSVGHeight = powerCatSVG.attr("height");
        powerCatSVG.selectAll("*").remove();

        var xScale = d3.scaleLinear()
                        .domain([0, 120])
                        .range([padding, powerCatSVGWidth - 10]);

        var yScale = d3.scaleBand()
                        .domain(powerCat)
                        .rangeRound([0, powerCatSVGHeight - padding])
                        .padding(1);

        var xAxis = d3.axisBottom()
                        .scale(xScale)
                        .ticks(5);

        var yAxis = d3.axisLeft()
                     .scale(yScale)
                     .tickFormat(function(d, i) { return dataPlot[i].key; });

        powerCatSVG.selectAll("line")
                    .data(dataPlot)
                    .enter()
                    .append("line")
                    .attr("id", "barplot-line")
                    .attr("x1", xScale(0))
                    .attr("x2", function(d) { return xScale(d.value); })
                    .attr("y1", function(d) { return yScale(d.key); })
                    .attr("y2", function(d) { return yScale(d.key); });

        powerCatSVG.selectAll("mycircle")
                    .data(dataPlot)
                    .enter()
                    .append("circle")
                    .attr("id", "barplot-circle")
                    .attr("cx", function(d) { return xScale(d.value); })
                    .attr("cy", function(d) { return yScale(d.key); })
                    .attr("r", "4");

        powerCatSVG.append("g")
                    .attr("class", "xaxis")
                    .attr("transform", "translate(0," + (powerCatSVGHeight - padding) + ")")
                    .call(xAxis);

        powerCatSVG.append("g")
                    .attr("class", "yaxis")
                    .attr("transform", "translate(" + padding + ",0)")
                    .call(yAxis);
    };
    plot("DC", dataset);
    plot("Marvel", dataset);

    d3.select("#DC-dropdown")
        .on("change", function(d) {
            var selectedOption = d3.select(this).property("value");
            console.log(selectedOption);
        });

});
*/
/*
    var data = dataset.filter(function(d) { return d.appearances >= 100; })
    data.sort(function(a, b) { return b.appearances - a.appearances; })

    var n = 5;
    var ndx = crossfilter(data);

    var intelligenceDimension = ndx.dimension(function(d) { return d.intelligence; })
    var topIntelligence = intelligenceDimension.top(n);
    //console.log(topIntelligence);
    //console.log(intelligenceDimension.top(10));
    //console.log(data.filter(function(d) { return d.intelligence == 88; } ));

    var strengthDimension = ndx.dimension(function(d) { return d.strength; })
    //console.log(strengthDimension.top(10));
    //console.log(data.filter(function(d) { return d.strength == 90; } ));

    var speedDimension = ndx.dimension(function(d) { return d.speed; })
    //console.log(speedDimension.top(10));

    var durabilityDimension = ndx.dimension(function(d) { return d.durability; })
    //console.log(durabilityDimension.top(10));

    var powerDimension = ndx.dimension(function(d) { return d.power; })
    //console.log(powerDimension.top(10));
    //console.log(data.filter(function(d) { return d.power == 100; } ));

    var combatDimension = ndx.dimension(function(d) { return d.combat; })
    //console.log(combatDimension.top(10));

    var totalDimension = ndx.dimension(function(d) { return d.total; })
    //console.log(totalDimension.top(10));

    var intelligenceSVG = d3.select("#dc-power").select("svg");
    var intelligenceSVGWidth = intelligenceSVG.attr("width");
    var intelligenceSVGHeight = intelligenceSVG.attr("height");

    var xScale = d3.scaleLinear()
                    .domain([0, d3.max(topIntelligence, function(d) { return d.intelligence; })])
                    //.range([padding, intelligenceSVGWidth]);
                    .range([padding, intelligenceSVGWidth - (padding/6)]);

    var yScale = d3.scaleBand()
                    .domain(d3.range(topIntelligence.length))
                    .rangeRound([0, intelligenceSVGHeight - padding])
                    .paddingInner(0.05);

    var xAxis = d3.axisBottom()
                    .scale(xScale);

    var yAxis = d3.axisLeft()
                 .scale(yScale)
                 .tickFormat(function(d, i) { return topIntelligence[i].name; })

    intelligenceSVG.selectAll("rect")
                    .data(topIntelligence)
                    .enter()
                    .append("rect")
                    .attr("x", xScale(0))
                    .attr("y", function(d, i) {
                        return yScale(i);
                    })
                    .attr("width", function(d) {
                        return xScale(d.intelligence) - padding;
                    })
                    .attr("height", yScale.bandwidth())
                    .attr("fill", function(d) {
                        if (d.gender == "Female") {
                            return "#e41a1c";
                        } else if (d.gender == "Male") {
                            return "#377eb8";
                        } else {
                            return "#4daf4a";
                        }
                    })
                    .on("mouseover", function(d) {
                        var xPosition = parseFloat(d3.select(this).attr("width")) + padding - 25;
                        var yPosition = parseFloat(d3.select(this).attr("y")) + yScale.bandwidth() / 2 + 4;
                        powerSVG.append("text")
                                .attr("id", "tooltip")
                                .attr("x", xPosition)
                                .attr("y", yPosition)
                                .text(Math.round(d.total));
                    })
                    .on("mouseout", function(d) {
                        d3.select("#tooltip").remove();
                    });

    intelligenceSVG.append("g")
                    .attr("class", "xaxis")
                    .attr("transform", "translate(0," + (intelligenceSVGHeight - padding) + ")")
                    .call(xAxis);

    intelligenceSVG.append("g")
                    .attr("class", "yaxis")
                    .attr("transform", "translate(" + padding + ",0)")
                    .call(yAxis);

});*/
/*
d3.csv("https://raw.githubusercontent.com/holtzy/data_to_viz/master/Example_dataset/7_OneCatOneNum_header.csv", function(data) {
    console.log(data);
    console.log(typeof(data));
});*/
