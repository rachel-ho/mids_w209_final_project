//Globe Animation
var locations = [
    {"latitude": 22, "longitude": 88}, //batman
    {"latitude": 21, "longitude": 38}, //deadpool
    {"latitude": 30, "longitude": -58}, //green lantern
    {"latitude": 30, "longitude": -170}, //hulk
    {"latitude": 28, "longitude": 1.659626}, //iron man
    {"latitude": 60, "longitude": -4}, //joker
    {"latitude": 36, "longitude": 128}, //spider man
    {"latitude": 24, "longitude": -103} //wonder woman
];

var universeSVG = d3.select("#universe").select("svg")
var imageGroup = universeSVG.append('g');
var universeSVGWidth = universeSVG.attr("width");
var universeSVGHeight = universeSVG.attr("height");
var center = [universeSVGWidth / 2, universeSVGHeight / 2];
var velocity = 0.015;
var verticalTilt = -20;
var horizontalTilt = 0;

var graticule = d3.geoGraticule();

var projection = d3.geoOrthographic()
                    .scale(200)
                    .translate([universeSVGWidth / 2, universeSVGHeight / 2]);

var path = d3.geoPath()
                .projection(projection);


function plotUniverse() {
    universeSVG.append("circle")
                .attr("id", "sphere")
                .attr("cx", universeSVGWidth / 2)
                .attr("cy", universeSVGHeight / 2)
                .attr("r", 200)
                .attr("stroke", "#ffffff");
    plotImage();
}

function plotGraticule() {
    universeSVG.append("path")
                .datum(graticule)
                .attr("id", "graticule")
                .attr("stroke", "#ffffff");
}

function rotateUniverse() {
    d3.timer(function(elapsed) {
        projection.rotate([velocity * elapsed, verticalTilt, horizontalTilt]);
        universeSVG.selectAll("path").attr("d", path);
        plotImage();
    });
}

function plotImage() {
    var superhero = ["batman", "deadpool", "greenlantern", "hulk", "ironman", "joker", "spiderman", "wonderwoman"];
    var images = imageGroup.selectAll('image')
                            .data(locations);

    images.enter()
            .append("svg:image")
            .merge(images)
            .attr("x", function(d) { return projection([d.longitude, d.latitude])[0]; })
            .attr("y", function(d) { return projection([d.longitude, d.latitude])[1]; })
            .attr("xlink:href", function(d, i) {
                var coordinate = [d.longitude, d.latitude];
                distance = d3.geoDistance(coordinate, projection.invert(center));
                return distance > 1.57 ? "image/transparent.png" : "image/" + superhero[i] + ".png";
            })
            .attr("width", "80")
            .attr("height", "80");

    imageGroup.each(function () { this.parentNode.appendChild(this); })
}

plotUniverse();
plotGraticule();
rotateUniverse();


//Trend Viz
var padding1 = 80;
var padding2 = 170;
var parseTime = d3.timeParse("%Y-%m-%e");
var rowConverter1 = function(d) {
    return {
        name: d.Name,
        alignment: d.Alignment,
        gender: d.Gender,
        publisher: d.Publisher,
        identity: d.Identity,
        race: d.Race,
        status: d.Status,
        eyeColor: d.EyeColor,
        hairColor: d.HairColor,
        skinColor: d.SkinColor,
        height: parseFloat(d.Height),
        weight: parseFloat(d.Weight),
        appearances: parseFloat(d.Appearances),
        yearFirstAppearance: parseFloat(d.Year),
        dateFirstAppearance: parseTime(d.FirstAppearance),
        additional: d.AdditionalData
    };
}

d3.csv("https://raw.githubusercontent.com/rachel-ho/mids_w209_final_project/master/superheroes_info_proc.csv", rowConverter1).then(function(dataset) {
    var data = dataset.filter(function(d) { return !isNaN(d.yearFirstAppearance); })
    //console.log(data);

    var ndx = crossfilter(data);
    var yearBinDimension = ndx.dimension(function(d) { return Math.floor(d.yearFirstAppearance / 5) * 5; })
    var yearBinCount = yearBinDimension.group().all();
    //console.log(yearBinCount);

    function reduceAddAlignment(p, v) {
        ++p.Total;
        p.Bad += (v.alignment == "Bad") ? 1 : 0;
        p.Good += (v.alignment == "Good") ? 1 : 0;
        p.Neutral += (v.alignment == "Other") ? 1 : 0;
        return p;
    }
    function reduceRemoveAlignment(p, v) {
        --p.Total;
        p.Bad -= (v.alignment == "Bad") ? 1 : 0;
        p.Good -= (v.alignment == "Good") ? 1 : 0;
        p.Neutral -= (v.alignment == "Other") ? 1 : 0;
        return p;
    }
    function reduceInitialAlignment() {
        return {Total: 0, Bad: 0, Good: 0, Neutral: 0};
    }
    var alignmentByYear = yearBinDimension.group().reduce(reduceAddAlignment, reduceRemoveAlignment, reduceInitialAlignment).all();
    //console.log(alignmentByYear);

    var alignmentByYearFlat = [];
    for (var i = 0; i < alignmentByYear.length; i++) {
        alignmentByYearFlat.push(alignmentByYear[i].value);
    }
    //console.log(alignmentByYearFlat);

    function reduceAddGender(p, v) {
        ++p.Total;
        p.Male += (v.gender == "Male") ? 1 : 0;
        p.Female += (v.gender == "Female") ? 1 : 0;
        p.Other += (v.gender == "Other") ? 1 : 0;
        return p;
    }
    function reduceRemoveGender(p, v) {
        --p.Total;
        p.Male -= (v.gender == "Male") ? 1 : 0;
        p.Female -= (v.gender == "Female") ? 1 : 0;
        p.Other -= (v.gender == "Other") == -1 ? 1 : 0;
        return p;
    }
    function reduceInitialGender() {
        return {Total: 0, Male: 0, Female: 0, Other: 0};
    }
    var genderByYear = yearBinDimension.group().reduce(reduceAddGender, reduceRemoveGender, reduceInitialGender).all();
    //console.log(genderByYear);

    var genderByYearFlat = [];
    for (var i = 0; i < genderByYear.length; i++) {
        genderByYearFlat.push(genderByYear[i].value);
    }
    //console.log(genderByYearFlat);

    function reduceAddPublisher(p, v) {
        ++p.Total;
        p.Marvel += (v.publisher == "Marvel") ? 1 : 0;
        p.DC += (v.publisher == "DC") ? 1 : 0;
        p.Other += (v.publisher == "Other") ? 1 : 0;
        return p;
    }
    function reduceRemovePublisher(p, v) {
        --p.Total;
        p.Marvel -= (v.publisher == "Marvel") ? 1 : 0;
        p.DC -= (v.publisher == "DC") ? 1 : 0;
        p.Other -= (v.publisher == "Other") ? 1 : 0;
        return p;
    }
    function reduceInitialPublisher() {
        return {Total: 0, Marvel: 0, DC: 0, Other: 0};
    }
    var publisherByYear = yearBinDimension.group().reduce(reduceAddPublisher, reduceRemovePublisher, reduceInitialPublisher).all();
    //console.log(publisherByYear);

    var publisherByYearFlat = [];
    for (var i = 0; i < publisherByYear.length; i++) {
        publisherByYearFlat.push(publisherByYear[i].value);
    }
    //console.log(publisherByYearFlat);

    var trendSVG = d3.select("#trend").select("svg");
    var trendSVGWidth = trendSVG.attr("width");
    var trendSVGHeight = trendSVG.attr("height");

    //console.log(Object.getOwnPropertyNames(genderByYear[0].value).slice(1));
    var stack = d3.stack()
                    .keys(Object.getOwnPropertyNames(publisherByYear[0].value).slice(1))
                    .order(d3.stackOrderDescending);

    var series = stack(publisherByYearFlat);
    //console.log(series);

    var xScale = d3.scaleBand()
                    .domain(d3.range(yearBinCount.length))
                    .range([padding1, trendSVGWidth])
                    .paddingInner(0.05);

    var yScale = d3.scaleLinear()
                    .domain([0, d3.max(publisherByYear, function(d) { return d.value.Total; })])
                    .range([trendSVGHeight - padding1, 0]);

    var xAxis = d3.axisBottom()
                    .scale(xScale)
                    .tickFormat(function(d, i) { return yearBinCount[i].key; });

    var yAxis = d3.axisLeft()
                 .scale(yScale)
                 .ticks(5);

    var colors = d3.scaleOrdinal().domain(d3.range(9)).range(d3.schemeSet1);
    //console.log(colors(2));

    var trendGroup = trendSVG.selectAll("g")
                                .data(series)
                                .enter()
                                .append("g")
                                .style("fill", function(d, i) { return colors(i); });


    var trendRect = trendGroup.selectAll("rect")
                                .data(function(d) { return d; })
                                .enter()
                                .append("rect")
                                .attr("x", function(d, i) { return xScale(i); })
                                .attr("y", function(d) { return yScale(d[1]); })
                                .attr("width", xScale.bandwidth())
                                .attr("height", function(d) { return yScale(d[0]) - yScale(d[1]); })
                                .attr("count", function(d) { return d[1] - d[0]; } )
                                .attr("percentage", function(d) { return (d[1] - d[0]) / d.data.Total; });

    trendSVG.append("g")
            .attr("class", "xaxis")
            .attr("transform", "translate(0," + (trendSVGHeight - padding1) + ")")
            .call(xAxis);

    trendSVG.append("g")
            .attr("class", "yaxis")
            .attr("transform", "translate(" + padding1 + ",0)")
            .call(yAxis);

    trendSVG.append("g")
            .append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", padding1 - 60)
            .attr("x", (-trendSVGHeight + padding1) / 2)
            .text("Number of Superheroes Created")
            .style ("text-anchor", "middle");

    var legendScale = d3.scaleOrdinal()
                        .domain(Object.getOwnPropertyNames(publisherByYear[0].value).slice(1,3))
                        .range(["#e41a1c", "#377eb8"]);

    var legendOrdinal = d3.legendColor()
                            .orient("vertical")
                            .scale(legendScale);

    trendSVG.append("g")
            .attr("id", "legend")
            .attr("transform", "translate(" + (padding1 + 30) + ", 10)")
            .call(legendOrdinal);

    trendSVG.selectAll("g")
            .selectAll("rect")
            .on("mouseover", function(d) {
                var trendDiv = document.getElementById("trend");
                var xPosition = parseFloat(d3.select(this).attr("x")) + xScale.bandwidth() / 2;
                var yPosition = parseFloat(d3.select(this).attr("y")) / 2 + trendSVGHeight / 2;

                d3.select("#tooltip")
                    .style("left", (xPosition + trendDiv.offsetLeft) + "px")
                    .style("top", (yPosition + trendDiv.offsetTop) + "px")
                    .select("#count")
                    .text(d3.select(this).attr("count"));

                d3.select("#tooltip")
                    .style("left", (xPosition + trendDiv.offsetLeft) + "px")
                    .style("top", (yPosition + trendDiv.offsetTop) + "px")
                    .select("#percentage")
                    .text((d3.select(this).attr("percentage") * 100).toFixed(1) + "%");

				d3.select("#tooltip").classed("hidden", false);

            })
            .on("mouseout", function(d) {
                d3.select("#tooltip").classed("hidden", true);
            });

    d3.selectAll("#radio")
        .on("click", function() {
            var view = d3.select(this).node().value;

            switch (view) {
                case "alignment":
                    stack.keys(Object.getOwnPropertyNames(alignmentByYear[0].value).slice(1));
                    series = stack(alignmentByYearFlat);

                    trendSVG.selectAll("g")
                            .data(series)
                            .style("fill", function(d, i) { return colors(i+6); })
                            .selectAll("rect")
                            .data(function(d) { return d; })
                            .transition("stacked-bar-transition")
                            .duration(1000)
                            .attr("y", function(d) { return yScale(d[1]); })
                            .attr("height", function(d) { return yScale(d[0]) - yScale(d[1]); })
                            .attr("count", function(d) { return d[1] - d[0]; } )
                            .attr("percentage", function(d) { return (d[1] - d[0]) / d.data.Total; });

                    legendScale.domain(Object.getOwnPropertyNames(alignmentByYear[0].value).slice(1))
                                .range(["#a65628", "#f781bf", "#999999"]);
                    trendSVG.select("#legend")
                            .call(legendOrdinal);
                    break;

                case "gender":
                    stack.keys(Object.getOwnPropertyNames(genderByYear[0].value).slice(1));
                    series = stack(genderByYearFlat);

                    trendSVG.selectAll("g")
                            .data(series)
                            .style("fill", function(d, i) { return colors(i+3); })
                            .selectAll("rect")
                            .data(function(d) { return d; })
                            .transition()
                            .duration(1000)
                            .attr("y", function(d) { return yScale(d[1]); })
                            .attr("height", function(d) { return yScale(d[0]) - yScale(d[1]); })
                            .attr("count", function(d) { return d[1] - d[0]; } )
                            .attr("percentage", function(d) { return (d[1] - d[0]) / d.data.Total; });

                    legendScale.domain(Object.getOwnPropertyNames(genderByYear[0].value).slice(1))
                                .range(["#984ea3", "#ff7f00", "#ffff33"]);
                    trendSVG.select("#legend")
                            .call(legendOrdinal);
                    break;

                case "publisher":
                    stack.keys(Object.getOwnPropertyNames(publisherByYear[0].value).slice(1));
                    series = stack(publisherByYearFlat);

                    trendSVG.selectAll("g")
                            .data(series)
                            .style("fill", function(d, i) { return colors(i); })
                            .selectAll("rect")
                            .data(function(d) { return d; })
                            .transition()
                            .duration(1000)
                            .attr("y", function(d) { return yScale(d[1]); })
                            .attr("height", function(d) { return yScale(d[0]) - yScale(d[1]); })
                            .attr("count", function(d) { return d[1] - d[0]; } )
                            .attr("percentage", function(d) { return (d[1] - d[0]) / d.data.Total; });

                    legendScale.domain(Object.getOwnPropertyNames(publisherByYear[0].value).slice(1,3))
                                .range(["#e41a1c", "#377eb8"]);
                    trendSVG.select("#legend")
                            .call(legendOrdinal);
                    break;
            };
        });

});


//Most Powerful Viz
var rowConverter2 = function(d) {
    return {
        name: d.Name,
        Intelligence: parseFloat(d.Intelligence),
        Strength: parseFloat(d.Strength),
        Speed: parseFloat(d.Speed),
        Durability: parseFloat(d.Durability),
        Power: parseFloat(d.Power),
        Combat: parseFloat(d.Combat),
        total: parseFloat(d.Total),
        alignment: d.Alignment,
        gender: d.Gender,
        publisher: d.Publisher,
        appearances: parseFloat(d.Appearances),
    };
}

d3.csv("https://raw.githubusercontent.com/rachel-ho/mids_w209_final_project/master/superheroes_stats_proc.csv", rowConverter2).then(function(dataset) {
    function plot(publisher, inputData) {
        var data = inputData.filter(function(d) { return (d.publisher == publisher) && (d.total != 0); })
        //console.log(data);

        var n = 10;
        var ndx = crossfilter(data);
        var powerDimension = ndx.dimension(function(d) { return d.total; })
        var topPower = powerDimension.top(n);
        //console.log(topPower);

        var powerSVG = d3.select("#" + publisher + "-power").select("svg");
        var powerSVGWidth = powerSVG.attr("width");
        var powerSVGHeight = powerSVG.attr("height");
        powerSVG.selectAll("*").remove();

        var xScale = d3.scaleLinear()
                        .domain([0, d3.max(topPower, function(d) { return d.total; })])
                        .range([padding2, powerSVGWidth - 10]);

        var yScale = d3.scaleBand()
                        .domain(d3.range(topPower.length))
                        .rangeRound([0, powerSVGHeight - padding2])
                        .padding(0.8);

        var xAxis = d3.axisBottom()
                        .scale(xScale)
                        .ticks(5);

        var yAxis = d3.axisLeft()
                     .scale(yScale)
                     .tickFormat(function(d, i) { return topPower[i].name; });

        var bars = powerSVG.selectAll("rect")
                            .data(topPower);

        bars.exit()
            .transition()
            .duration(1000)
            .attr("x", powerSVGWidth)
            .remove();

        bars.enter()
            .append("rect")
            .attr("x", xScale(0))
            .attr("y", function(d, i) {
                return yScale(i);
            })
            .attr("height", yScale.bandwidth())
            .attr("fill", function(d) {
                if (d.publisher == "Marvel") {
                    return "#e41a1c";
                } else {
                    return "#377eb8";
                }
            })
            .merge(bars)
            .transition("bar-transition")
            .duration(1000)
            .attr("width", function(d) {
                return xScale(d.total) - padding2;
            })
            .attr("fill", function(d) {
                if (d.publisher == "Marvel") {
                    return "#e41a1c";
                } else {
                    return "#377eb8";
                }
            });

        powerSVG.selectAll("label")
                .data(topPower)
                .enter()
                .append("text")
                .attr("x", function(d) { return xScale(d.total); })
                .attr("dx", "-1.8em")
                .attr("y", function(d, i) { return yScale(i); })
                .attr("dy", "-0.3em")
                .style("fill", "#000000")
                .transition("label-transition")
                .duration(1000)
                .style("fill", function(d) {
                    if (d.publisher == "Marvel") {
                        return "#e41a1c";
                    } else {
                        return "#377eb8";
                    }
                })
                .text(function(d) { return d.total; });

        powerSVG.append("g")
                .attr("class", "xaxis")
                .attr("transform", "translate(0," + (powerSVGHeight - padding2) + ")")
                .call(xAxis);

        powerSVG.append("g")
                .attr("class", "yaxis-ranking")
                .attr("transform", "translate(" + padding2 + ",0)")
                .transition("yaxis-transition")
                .duration(1000)
                .call(yAxis);
    };

    plot("DC", dataset);
    plot("Marvel", dataset);

    d3.selectAll("#slider")
        .on("change", function() {
            var threshold = +d3.select(this).node().value;
            //console.log(threshold);
            var filterData = dataset.filter(function(d) { return d.appearances >= threshold; })
            plot("DC", filterData);
            plot("Marvel", filterData);
        });
});


//Power Comparision Viz
d3.csv("https://raw.githubusercontent.com/rachel-ho/mids_w209_final_project/master/superheroes_stats_proc.csv", rowConverter2).then(function(dataset) {
    var n = 45;
    var powerCat = ["Combat", "Durability", "Intelligence", "Power", "Speed", "Strength"];
    var dcData = dataset.filter(function(d) { return (d.publisher == "DC") && (d.total != 0); })
                        .sort(function(a, b) { return b.appearances - a.appearances; })
                        .slice(0, n)
                        .sort(function(a, b) { return a.name.localeCompare(b.name); });

    var marvelData = dataset.filter(function(d) { return (d.publisher == "Marvel") && (d.total != 0); })
                            .sort(function(a, b) { return b.appearances - a.appearances; })
                            .slice(0, n)
                            .sort(function(a, b) { return a.name.localeCompare(b.name); });;
    //console.log(dcData);
    //console.log(marvelData);

    function createDropdown(publisher, inputData) {
        d3.select("#" + publisher + "-dropdown")
            .selectAll("option")
            .data(inputData)
            .enter()
            .append("option")
            .text(function(d) { return d.name; });
    };

    createDropdown("DC", dcData);
    createDropdown("Marvel", marvelData);

    var dcDefaultCharacter = dcData[0].name;
    var marvelDefaultCharacter = marvelData[0].name;
    //console.log(dcDefaultCharacter);
    //console.log(marvelDefaultCharacter);
    var dcDefaultIndex = dcData.findIndex(function(d) { return d.name == dcDefaultCharacter; });
    var marvelDefaultIndex = marvelData.findIndex(function(d) { return d.name == marvelDefaultCharacter; });
    //console.log(dcDefaultIndex);
    //console.log(marvelDefaultIndex);

    d3.select("#Marvel-text-svg")
        .select("text")
        .append("tspan")
        .attr("y", 30)
        .attr("fill", "#e41a1c")
        .style("font-size", 20)
        .text(marvelData[marvelDefaultIndex].total);
        //console.log(marvelData[marvelDefaultIndex]);

    d3.select("#DC-text-svg")
        .select("text")
        .append("tspan")
        .attr("y", 30)
        .attr("fill", "#377eb8")
        .style("font-size", 20)
        .text(dcData[dcDefaultIndex].total);

    function plotDC(index) {
        var dataPlot = Object.entries(dcData[index])
                                .map(([key, value]) => ({key, value}))
                                .filter(function(d) { return powerCat.indexOf(d.key) > -1; })
                                .sort(function(a, b) { return (a.key > b.key) ? 1 : ((b.key > a.key) ? -1 : 0)});
        //console.log(dataPlot);

        var powerCatSVG = d3.select("#DC-chart-svg");
        var powerCatSVGWidth = powerCatSVG.attr("width");
        var powerCatSVGHeight = powerCatSVG.attr("height");
        powerCatSVG.selectAll("*").remove();

        var xScale = d3.scaleLinear()
                        .domain([0, 120])
                        .range([padding1, powerCatSVGWidth - 10]);

        var yScale = d3.scaleBand()
                        .domain(powerCat)
                        .rangeRound([0, powerCatSVGHeight - padding1])
                        .padding(1);

        var xAxis = d3.axisBottom()
                        .scale(xScale)
                        .ticks(5);

        var yAxis = d3.axisLeft()
                        .scale(yScale)
                        .tickFormat(function(d, i) { return dataPlot[i].key; });

        powerCatSVG.selectAll("line")
                    .data(dataPlot)
                    .enter()
                    .append("line")
                    .attr("id", "barplot-line")
                    .attr("x1", xScale(0))
                    .attr("x2", xScale(0))
                    .attr("y1", function(d) { return yScale(d.key); })
                    .attr("y2", function(d) { return yScale(d.key); })
                    .attr("stroke", "#ffffff")
                    .transition("line-transition")
                    .duration(1000)
                    .attr("x2", function(d) { return xScale(d.value); });

        powerCatSVG.selectAll("circle")
                    .data(dataPlot)
                    .enter()
                    .append("circle")
                    .attr("id", "barplot-circle")
                    .attr("cx", xScale(0))
                    .attr("cy", function(d) { return yScale(d.key); })
                    .transition("circle-transition")
                    .duration(1000)
                    .attr("cx", function(d) { return xScale(d.value); })
                    .attr("r", "5")
                    .style("fill", "#377eb8");

        powerCatSVG.selectAll("label")
                    .data(dataPlot)
                    .enter()
                    .append("text")
                    .attr("x", function(d) { return xScale(d.value); })
                    .attr("dx", "1em")
                    .attr("y", function(d) { return yScale(d.key); })
                    .attr("dy", ".35em")
                    .style("fill", "#000000")
                    .transition("label-transition")
                    .duration(1000)
                    .style("fill", "#377eb8")
                    .text(function(d) { return d.value; });

        powerCatSVG.append("g")
                    .attr("class", "xaxis")
                    .attr("transform", "translate(0," + (powerCatSVGHeight - padding1) + ")")
                    .call(xAxis);

        powerCatSVG.append("g")
                    .attr("class", "yaxis")
                    .attr("transform", "translate(" + padding1 + ",0)")
                    .call(yAxis);
    };

    function plotMarvel(index) {
        var dataPlot = Object.entries(marvelData[index])
                                .map(([key, value]) => ({key, value}))
                                .filter(function(d) { return powerCat.indexOf(d.key) > -1; })
                                .sort(function(a, b) { return (a.key > b.key) ? 1 : ((b.key > a.key) ? -1 : 0)});
            //console.log(dataPlot);
        var powerCatSVG = d3.select("#Marvel-chart-svg");
        var powerCatSVGWidth = powerCatSVG.attr("width");
        var powerCatSVGHeight = powerCatSVG.attr("height");
        powerCatSVG.selectAll("*").remove();

        var xScale = d3.scaleLinear()
                        .domain([0, 120])
                        .range([padding1, powerCatSVGWidth - 10]);

        var yScale = d3.scaleBand()
                        .domain(powerCat)
                        .rangeRound([0, powerCatSVGHeight - padding1])
                        .padding(1);

        var xAxis = d3.axisBottom()
                        .scale(xScale)
                        .ticks(5);

        var yAxis = d3.axisLeft()
                        .scale(yScale)
                        .tickFormat(function(d, i) { return dataPlot[i].key; });

        powerCatSVG.selectAll("line")
                    .data(dataPlot)
                    .enter()
                    .append("line")
                    .attr("id", "barplot-line")
                    .attr("x1", xScale(0))
                    .attr("x2", xScale(0))
                    .attr("y1", function(d) { return yScale(d.key); })
                    .attr("y2", function(d) { return yScale(d.key); })
                    .attr("stroke", "#ffffff")
                    .transition("line-transition")
                    .duration(1000)
                    .attr("x2", function(d) { return xScale(d.value); });

        powerCatSVG.selectAll("circle")
                    .data(dataPlot)
                    .enter()
                    .append("circle")
                    .attr("id", "barplot-circle")
                    .attr("cx", xScale(0))
                    .attr("cy", function(d) { return yScale(d.key); })
                    .transition("circle-transition")
                    .duration(1000)
                    .attr("cx", function(d) { return xScale(d.value); })
                    .attr("r", "5")
                    .style("fill", "#e41a1c");

        powerCatSVG.selectAll("label")
                    .data(dataPlot)
                    .enter()
                    .append("text")
                    .attr("x", function(d) { return xScale(d.value); })
                    .attr("dx", "1em")
                    .attr("y", function(d) { return yScale(d.key); })
                    .attr("dy", ".35em")
                    .style("fill", "#000000")
                    .transition("label-transition")
                    .duration(1000)
                    .style("fill", "#e41a1c")
                    .text(function(d) { return d.value; });

        powerCatSVG.append("g")
                    .attr("class", "xaxis")
                    .attr("transform", "translate(0," + (powerCatSVGHeight - padding1) + ")")
                    .call(xAxis);

        powerCatSVG.append("g")
                    .attr("class", "yaxis")
                    .attr("transform", "translate(" + padding1 + ",0)")
                    .call(yAxis);
    };

    plotDC(dcDefaultIndex);
    plotMarvel(marvelDefaultIndex);

    d3.select("#DC-dropdown")
        .on("change", function(d) {
            var selectedCharacter = d3.select(this).property("value");
            //console.log(selectedCharacter);
            var selectedIndex = dcData.findIndex(function(d) { return d.name == selectedCharacter; });
            plotDC(selectedIndex);

            d3.select("#DC-text-svg")
                .select("tspan")
                .remove();

            d3.select("#DC-text-svg")
                .select("text")
                .append("tspan")
                .attr("y", 30)
                .attr("fill", "#377eb8")
                .style("font-size", 20)
                .text(dcData[selectedIndex].total);
        });

    d3.select("#Marvel-dropdown")
        .on("change", function(d) {
            var selectedCharacter = d3.select(this).property("value");
            //console.log(selectedCharacter);
            var selectedIndex = marvelData.findIndex(function(d) { return d.name == selectedCharacter; });
            plotMarvel(selectedIndex);

            d3.select("#Marvel-text-svg")
                .select("tspan")
                .remove();

            d3.select("#Marvel-text-svg")
                .select("text")
                .append("tspan")
                .attr("y", 30)
                .attr("fill", "#e41a1c")
                .style("font-size", 20)
                .text(marvelData[selectedIndex].total);
        });

});
