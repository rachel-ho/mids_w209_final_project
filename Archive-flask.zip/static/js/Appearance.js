//(function(){

    //1510
    var width = 700,
        height = 400,
        textWidth = 100;

    var xNudge = 50,
        yNudge = 20;

    var svg = d3.select("#popularity")
      .append("svg")
      .attr("height", height)
      .attr("width", width)
      .append("g")


    //Define and draw image pettern
    var defs = svg.append("defs");

    var radiusScale = d3.scaleSqrt().domain([400,4100]).range([10,60])


    //Create a simulation
    //Step1: center the circle
    //Step2: make them not collide.  As long as the radius of the circle is the same as the value of forceCollide(), they are not going to collide
    var simulation = d3.forceSimulation()
      .force("x", d3.forceX(width/2).strength(0.07))
      .force("y", d3.forceY(height/2).strength(0.07))
      .force("collide", d3.forceCollide(function(d){
        return radiusScale(d.Appearances) + 0.8;
      }))

/*
    d3.queue()
      .defer(d3.csv, "data/superheroes_info_proc_bubble.csv")
      .await(ready);*/

  //Create the circle
d3.csv("static/data/superheroes_info_proc_bubble.csv").then(function(datapoints) {

  //(function ready(error, datapoints){


    //Slice top 10 data points
    var topdata = datapoints.sort(function(d) {
        return d3.descending(d.Appearance);
      }).slice(0, 10);

    defs.selectAll(".superheros")
      //1
      .data(topdata)
      .enter().append("pattern")
      .attr("class", "superheros")
      .attr("id", function(d){
          return d.Name.toLowerCase().replace(/ /g, "-")
      })
      .attr("height", "100%")
      .attr("width", "100%")
      .attr("patternContentUnits", "objectBoundingBox")
      .append("image")
      .attr("height", 1)
      .attr("width", 1)
      .attr("preserveAspectRadio", "none")
      .attr("xmlns:xlink", "http://www.w3.org/1999/xlink")
      .attr("xlink:href", function(d){
          return d.Image_path
      })

    var circles = svg.selectAll(".Appearance")
      //2
      .data(topdata)
      .enter().append("circle")
      .on('mouseover', showDetail)
      .on('mouseout', hideDetail)
      .attr("class", "appearance")
      .attr("r", function(d){
        return radiusScale(d.Appearances);
      })
      .attr("fill", function(d){
           return "url(#"+ d.Name.toLowerCase().replace(/ /g, "-") +")"
      })

    simulation.nodes(topdata)
      .on('tick', ticked)
    //4
    function ticked(topdata){
      circles
        .attr("cx", function(d){
          return d.x
        })
        .attr("cy", function(d){
          return d.y
        })
    }


    // tooltip for mouseover functionality
    var tooltip = floatingTooltip('gates_tooltip', 240);

    function showDetail(d) {
      // change outline to indicate hover state.
      d3.select(this).attr('stroke', 'black');

      var content = '<span class="name">Name: </span><span class="value">' +
                    d.Name + '</span><br/>' +
                    '<span class="name"># of Appearances: </span><span class="appearance">' +
                                  d.Appearances + '</span><br/>'
                                  '<span class="name">Appearances: </span><span class="Gender">' +
                                                d.Gender + '</span><br/>';

      tooltip.showTooltip(content, d3.event);
    }

    function hideDetail(d) {
      // reset outline
      d3.select(this)
        .attr('stroke', "none");

      tooltip.hideTooltip();
    }

    //After click the button, reset position and split the bubble. Click again to regroup.
    d3.select('#popularity-button')
    //.selectAll('.button')
    .selectAll('#button')
    .on('click', function () {
        // Get the id of the button
        //var buttonId = d3.select(this).attr('id');
        var buttonId = d3.select(this).node().value;
        console.log(buttonId);

        if (buttonId == "publisher"){
          function fX (d) {
              var targetX;
              //var targetY;
              //if (d.Gender == "Male") {
              if (d.Publisher == "Marvel") {
                  targetX = width / 4;
                  //targetX = width/2;

              } else {
                  //targetX = width/3;
                  //targetX = width - 900;
                  targetX = width - 200;
              }
              return targetX;
          }

          simulation
              .force("x", d3.forceX(fX).strength(0.1))
              .force("y", d3.forceY(200).strength(0.1))

          simulation.alpha(1).restart();


        }
        else if (buttonId == "all"){
          console.log(buttonId);

          // addText1
          //     .text("Discover the Top 10 most popular superheros in the Marvel and DC universe!");
          // addText2
          //     .text("Which superhero has the most appearances since it first appeared");
          // addText3
          //     .text("in the comic book, Amazing Fantasy Issue 15 in 1962?");
          // addText4
          //     .text("The movie has generated more than $1,684,429,400 from 2002 to 2012.");
          // addText5
          //     .text("Hover to find out!");

            var center = { x: width / 2, y: height / 2 };
            //hideYearTitles();
            // @v4 Reset the 'x' force to draw the bubbles to the center.
            simulation
              .force('x', d3.forceX().strength(0.09).x(center.x));

            // @v4 We can reset the alpha value and restart the simulation
            simulation.alpha(1).restart();

            // simulation
            // .force("collide", d3.forceCollide(function(d){
            //   return radiusScale(d.Appearances) + 0.5;
            // }))
        }

    });

});





//})();
